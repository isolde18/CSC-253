﻿namespace UnitTestProjectForRPC
{
    internal class Calculation
    {
        private string v;
        private double retail_price;

        //public Calculation(string v, double retail_price)
        //{
        //    this.v = v;
        //    this.retail_price = retail_price;
        //}

       // public double Balance { get; internal set; }
    }
}