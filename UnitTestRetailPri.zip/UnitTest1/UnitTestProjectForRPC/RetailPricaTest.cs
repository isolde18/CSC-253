using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConsoleUI;

namespace UnitTestProjectForRPC
{
    [TestClass]
    public class RetailPricaTest
    {
        //private object retail_price;
        private object expected;

        [TestMethod]
        public void TestMethod1()
        {
            // Arrange
            double wholesale_price = 10.00;
            double markup_percentage = 0.5;
            double retail_price = 10.50;
           // Calculation account = new Calculation("This is the correct", retail_price);
            double actual = 10.50;
            Assert.AreEqual(retail_price, actual, 0.001,"This is not the correct calcuulation" +retail_price);


        }
    }
}
