﻿using System;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            //get user input
            System.Console.WriteLine("Enter the wholesale price");
            double wholesale_price = double.Parse(Console.ReadLine());

            //calculate the percentage
            System.Console.WriteLine("Enter the markup percentage");
            double num = double.Parse(Console.ReadLine()); ;

            double markup_percentage = num / 100 * wholesale_price;
            System.Console.WriteLine("The markup percentage after conversion is : " + markup_percentage);
            System.Console.ReadLine();

            //calculate the retail_price
            double retail_price = wholesale_price + markup_percentage;
            System.Console.WriteLine("The retail price is: " + retail_price);
            System.Console.ReadLine();

        }
    }
}
