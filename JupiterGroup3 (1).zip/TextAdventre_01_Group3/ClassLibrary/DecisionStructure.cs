﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class DecisionStructure
    {
        // Decides what to do based on userInput in StartMenu
        public static void StartMenuChoice(int choice)
        {
            switch(choice)
            {
                // If user chooses 1, they enter the dungeon
                case 1:
                    EnterDungeon();
                    break;
                // If user chooses 2, display info menu
                case 2:
                    InfoMenu();
                    break;
                // If user chooses 3, exit
                case 3:
                    Console.WriteLine("Goodbye!");
                    break;
            }
        }
        // Display enter dungeon menu
        public static void EnterDungeon()
        {
            // Array for rooms 
            Room[] rooms = {new Room("Dungeon Entrance", "The start area of the dugeon of Jupiter", "North - Woods", 1),
                            new Room("Wolf Den", "A place where the wolves group and is dangerous to be in.", "North" +
                             " - Eerie Room, South - Dungeon Entrance", 2),
                             new Room("Eerie Room", "A spooky room *gasp* could be a ghost in here.", "North" +
                             " - Treasure Room, South - Wolf Den", 3),
                             new Room("Treasure Room", "This room contains a mob and it will choose at random." +
                             " and will spawn a treasure if you defeat it", "North - Foggy Room, South - Eerie Room", 4),
                             new Room("Cave Room", "A very dark and gleemy room that is very closed in hard to be in.",
                             "North - Ancient Room, South - Treasure Room", 5),
                             new Room("Ancient Room", "A room that is covered in thousands of artifacts and treasures.",
                             "North - Hologram Room, South - Cave Room", 6),
                             new Room("Hologram Room", "A very confusing that projects these objects that move with you.",
                             "North - Maze Room, South - Ancient Room", 7),
                             new Room("Maze Room", "This room is a test to move around tp figure out your escape.",
                             "North - Secret Room, South - Hologram Room", 8),
                             new Room("Secret Room", "This room is really just a secret its random with something in it.",
                             "North - Boss Room, South - Maze Room", 9),
                             new Room("Boss Room", "This room is the end of the dungeon and this spawns the Goblin King",
                             "South - Secret Room",10)}; 
            List<Mob> mobs = new List<Mob>() { new Mob("Wolf", 20, 0, 2),
                                               new Mob("Goblin", 25, 2, 6),
                                               new Mob("Goblin Mage", 30, 3, 8),
                                               new Mob("Hobogoblin", 20, 1, 7),
                                               new Mob("Goblin Commander", 125, 20, 20),
                                               new Mob("Goblin King",250, 50, 35)};
            Player myPlayer = new Player();
            int index = 0;
            Console.WriteLine("Welcome to Jupiter");
            Console.WriteLine("-------------------------");
            Console.WriteLine("Main Menu");
            bool exit = false;

            do
            {
                Console.WriteLine($"Current name is - {rooms[index].Name}");
                Console.WriteLine(StandardMessages.DisplayMenu());
                switch (Console.ReadLine())
                {
                    case "1":
                    case "north":
                    case "North":
                        {
                            GoNorth(ref rooms, ref index);
                        }
                        break;
                    case "2":
                    case "south":
                    case "South":
                        {
                            GoSouth(ref rooms, ref index);
                        }
                        break;
                    case "3":
                    case "attack":
                    case "Attack":
                        {
                            ToAttack(ref mobs);
                        }
                        break;
                    case "4":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Not a valid choice.");
                        break;
                }
                Console.Write("Press the ENTER key to continue...");
                Console.ReadLine();
            } while (exit == false);
        }
        public static void GoNorth(ref Room[] room, ref int index)
        {
            if (index < room.Length)
            {
                if (index != room.Length - 1)
                {
                    index++;
                    Console.WriteLine($"You moved to {room[index].Name}");
                }
                else
                {
                    Console.WriteLine("Can't go further more.");
                }
            }
        }
        public static void GoSouth(ref Room[] room, ref int index)
        {
            if (index > 0)
            {
                index--;
                Console.WriteLine($"You moved to {room[index].Name}");
            }
            else
            {
                Console.WriteLine("You cant go any further!");
            }
        }
        public static void ToAttack(ref List<Mob> mobs)
        {
            Random rand = new Random();
            Console.Write($"You have a hit point of ");
            Console.Write(rand.Next(1, 20));
            Console.WriteLine($" to {mobs[0].Name}");
        }
        // Display Info Menu
        public static void InfoMenu()
        {
            bool exit = false;
            do
            {
                Console.WriteLine(StandardMessages.InfoMenu());
                switch (Console.ReadLine())
                {
                    case "1":
                        ArrayHolder.ClassArray();
                        Console.ReadLine();
                        break;
                    case "2":
                        ArrayHolder.RoomArray();
                        Console.ReadLine();
                        break;
                    case "3":
                        ArrayHolder.PotionArray();
                        Console.ReadLine();
                        break;
                    case "4":
                        ArrayHolder.TreasureArray();
                        Console.ReadLine();
                        break;
                    case "5":
                        ArrayHolder.ItemDescriptionArray();
                        Console.ReadLine();
                        break;
                    case "6":
                        ArrayHolder.WeaponArray();
                        Console.ReadLine();
                        break;
                    case "7":
                        ArrayHolder.AbilityArray();
                        Console.ReadLine();
                        break;
                    case "8":
                        ArrayHolder.MobArray();
                        Console.ReadLine();
                        break;
                    case "9":
                        ArrayHolder.StatArray();
                        Console.ReadLine();
                        break;
                    case "10":
                        Console.WriteLine("Goodbye!");
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid input! Choose again..");
                        break;
                }
            } while (exit == false);
        }
        // Sean Created method to check if user inputs a valid option
        public static int MenuChoiceValidation(int choice, int max)
        {
            // Check to see if user inputs an int and that int is between the lowest (always 1) and highest number for choices
            while (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > max)
            {
                // Inform user that input is invalid
                Console.WriteLine(StandardMessages.InputError());
            }
            // Return user input
            return choice;
        }

    }
}
