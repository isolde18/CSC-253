﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Player : Character
    {
        //Fields
        private string _password;
        private string _class;
        private string _race;
        private int _mana;
        private int _dexterity;
        private int _vitality;
        private int _wisdom;
        // Default Constructor
        public Player()
        {
            Class = "No Class";
            Race = "No Race";
            Mana = 0;
            Dexterity = 0;
            Vitality = 0;
            Wisdom = 0;
        }
        // Custom Constructor
        public Player(string name, int health, int armorpts, string playerClass, string race, int mana, int dexterity,
                      int vitality, int wisdom) : base(name, health, armorpts)
        {
            Class = playerClass;
            Race = race;
            Mana = mana;
            Dexterity = dexterity;
            Vitality = vitality;
            Wisdom = wisdom;
        }
        // Properties
        public string Class
        {
            get
            {
                return _class;
            }
            set
            {
                _class = value;
            }
        }
        public string Race
        {
            get
            {
                return _race;
            }
            set
            {
                _race = value;
            }
        }
        public int Mana
        {
            get
            {
                return _mana;
            }
            set
            {
                _mana = value;
            }
        }
        public int Dexterity
        {
            get
            {
                return _dexterity;
            }
            set
            {
                _mana = value;
            }
        }
        public int Vitality
        {
            get
            {
                return _vitality;
            }
            set
            {
                _vitality = value;
            }
        }
        public int Wisdom
        {
            get
            {
                return _wisdom;
            }
            set
            {
                _wisdom = value;
            }
        }
    }
}
