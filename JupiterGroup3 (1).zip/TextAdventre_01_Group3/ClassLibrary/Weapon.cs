﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Weapon : Object
    {
        // Fields
        private string _type;
        private int _damage;
        // Default Constructor
        public Weapon()
        {
            Type = "";
            Damage = 0;
        }
        // Custom Constructor
        public Weapon(string name, string description, int price, int units, bool equip,
            bool usable, string type, int damage) : base(name, description, price, units, equip, usable)
        {
            Type = type;
            Damage = damage;
        }
        // Properties
        public string Type
        {
            get
            {
                return _type;
            }
            set
            {
                _type = value;
            }
        }
        // Auto Property
        public int Damage { get; set; }
    }
}
