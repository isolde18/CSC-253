﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Mob : Character
    {
        // Fields
        private int _attackdmg;
        // Default Constructor
        public Mob()
        {
            AttackDamage = 0;
        }
        // Custom Constructor
        public Mob(string name, int health, int armorpts, int attackDamage)
            : base(name, health, armorpts)
        {
            AttackDamage = attackDamage;
        }
        // Properties
        public int AttackDamage
        {
            get
            {
                return _attackdmg;
            }
            set
            {
                _attackdmg = value;
            }
        }
    }
}
