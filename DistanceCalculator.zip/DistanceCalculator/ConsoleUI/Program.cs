﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;




    
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Enter the speed");
            //int speed =int.Parse(Console.ReadLine());
            //Console.WriteLine("Enter the miles");
            //int miles=int.Parse(Console.ReadLine());
            //int distance;
            //distance = miles * speed;
            //Console.WriteLine("This is the distance\n" +distance);
            //Console.ReadLine();
            getDistance();
            Console.ReadLine();
        }
       static void getDistance()
        {
            Console.WriteLine("Enter the speed");
            int s = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the miles");
            int m = int.Parse(Console.ReadLine());
            int d= s * m;
            Console.WriteLine("This is the distance\n" + d);
        }
    }
}
