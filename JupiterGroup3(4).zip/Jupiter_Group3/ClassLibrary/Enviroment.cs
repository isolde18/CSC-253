﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public static class Enviroment
    {
        // List for Rooms
        public static readonly List<Room> Rooms = new List<Room>();
        // List for Mobs
        public static readonly List<Mob> Mobs = new List<Mob>();
        // List for Treasure
        public static readonly List<Treasure> Treasures = new List<Treasure>();
        // List for Items
        public static readonly List<Item> Items = new List<Item>();
        // List for Weapons
        public static readonly List<Weapon> Weapons = new List<Weapon>();
        // List for Potions
        public static readonly List<Potion> Potions = new List<Potion>();
        // List for Player
        public static readonly List<string> playerList = new List<string>();

        public static Room RoomByTracker(int tracker)
        {
            return Rooms.SingleOrDefault(x => x.Tracker == tracker);
        }

        public static Mob MobByTracker(int tracker)
        {
            return Mobs.SingleOrDefault(x => x.Tracker == tracker);
        }
        public static Mob MobByName(string name)
        {
            return Mobs.SingleOrDefault(x => x.Name == name);
        }
    }
}
