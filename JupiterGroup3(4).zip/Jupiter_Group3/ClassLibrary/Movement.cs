﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public static class Movement
    {
        public static bool canMove = true;

        public static void NewLocation(Room location)
        {
            Enviroment.Rooms[Player.CurrentLocation] = location;
        }
        public static void Moving(Room location)
        {
            NewLocation(location);
        }
        public static void MoveToDirection(string input)
        {
            switch (input)
            {
                case "north":
                    if (Enviroment.Rooms[Player.CurrentLocation].TrackerNorth != -1)
                    {
                        Moving(Enviroment.Rooms[Enviroment.Rooms[Player.CurrentLocation].TrackerNorth]);
                    }
                    else
                    {
                        canMove = false;
                    }
                    break;
                case "east":
                    if (Enviroment.Rooms[Player.CurrentLocation].TrackerEast != -1)
                    {
                        Moving(Enviroment.Rooms[Enviroment.Rooms[Player.CurrentLocation].TrackerEast]);
                    }
                    else
                    {
                        canMove = false;
                    }
                    break;
                case "south":
                    if (Enviroment.Rooms[Player.CurrentLocation].TrackerSouth != -1)
                    {
                        Moving(Enviroment.Rooms[Enviroment.Rooms[Player.CurrentLocation].TrackerSouth]);
                    }
                    else
                    {
                        canMove = false;
                    }
                    break;
                case "west":
                    if (Enviroment.Rooms[Player.CurrentLocation].TrackerWest != -1)
                    {
                        Moving(Enviroment.Rooms[Enviroment.Rooms[Player.CurrentLocation].TrackerWest]);
                    }
                    else
                    {
                        canMove = false;
                    }
                    break;
            }
        }
    }
}
