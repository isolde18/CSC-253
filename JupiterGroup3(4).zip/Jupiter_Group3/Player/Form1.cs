﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary;

namespace Player
{
    public partial class Form1 : Form
    {
        int playerHpBar = 100;
        int mobHpBar = 100;
        Mob mob;
        ClassLibrary.Player myChar = new ClassLibrary.Player();
        
        public Form1()
        {
            InitializeComponent();
            StreamBuilder.Build();
            #region Player Stats Text
            
            myChar.Race = Enviroment.playerList[2];
            myChar.Class = Enviroment.playerList[1];
            myChar.Mana = int.Parse(Enviroment.playerList[4]);
            myChar.Dexterity = 50;
            myChar.Vitality = 60;
            myChar.Wisdom = 50;
            myChar.Armor = 10;
            myChar.Damage = Combat.BuildPlayerCombat(int.Parse(Enviroment.playerList[3])).Damage;
            
            richTextBox2.Text = $"Race: {myChar.Race} \n" +
                                $"Class: {myChar.Class} \n" +
                               $"Mana: {myChar.Mana} \n" +
                               $"Dexterity: {myChar.Dexterity} \n" +
                               $"Vitality: {myChar.Vitality} \n" +
                               $"Wisdom: {myChar.Wisdom} \n" +
                               $"Attack Damage: {myChar.Damage} \n";
            #endregion

            #region Inventory Text
            richTextBox4.Text = "                   Equipped         \n" +
                                "=============================\n" +
                                "Weapon: Rusty Daggers \n" +
                                "Armor: Basic Armor \n" +
                                "Ring: Ring of Stamina \n\n\n\n\n" +
                                "                   Other            \n" +
                                "=============================\n" +
                                "Potion of Healing x" + 2 + "\n" +
                                "Potion of Mana";





            #endregion



            richTextBox3.Text = "There is no mob.";
            
            richTextBox1.AppendText("\n" + Enviroment.Rooms[0].Name);
            richTextBox1.AppendText("\n" + Enviroment.Rooms[0].Description);

            
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        #region Player Movement Buttons
        private static bool canMove = true;
        public static void NewLocation(Room location)
        {
            Enviroment.Rooms[ClassLibrary.Player.CurrentLocation] = location;
        }
        public static void Moving(Room location)
        {
            NewLocation(location);
            Mob mob = new Mob();
            mob = Combat.BuildMobCombat();
            mob.Armor = Combat.BuildMobCombat().Armor;
            mob.AttackDamage = Combat.BuildMobCombat().AttackDamage;

            
        }

        private void GoNorth(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerNorth != -1)
            {
                Movement.Moving(Enviroment.Rooms[Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerNorth]);
                this.groupBox1.Text = Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].Name;
                
                richTextBox1.AppendText("\n" + Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].Description);
                if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].RoomMob != null)
                {

                    if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].MobsRoom.Tracker != 105)
                    {
                        Attack.Enabled = true;
                        Random rand = new Random();
                        int spawnMob = rand.Next(0, 5);
                        mob = new Mob(Enviroment.Mobs[spawnMob]);
                        richTextBox3.Text = $"Name: {mob.Name} \n" +
                                            $"Attack Damage: {mob.AttackDamage} \n" +
                                            $"Armor: {mob.Armor}";

                        string exits = "\nExits available: ";
                        List<string> trueExits = new List<string>();
                        if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerNorth != -1)
                            trueExits.Add("north");
                        if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerEast != -1)
                            trueExits.Add("east");
                        if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerSouth != -1)
                            trueExits.Add("south");
                        if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerWest != -1)
                            trueExits.Add("west");
                        if (trueExits.Count == 1)
                            exits += trueExits[0] + " ";
                        else
                        {
                            for (int i = 0; i < trueExits.Count; i++)
                            {
                                exits += trueExits[i];
                                if (i < trueExits.Count - 1)
                                    exits += ", ";
                            }
                        }
                        richTextBox1.AppendText("\n" + exits);
                        richTextBox1.AppendText("\n" + "There is a " + mob.Name + " lurking in your view of the room.");
                    }
                    else
                    {
                        mob = new Mob(Enviroment.Mobs[5]);
                        richTextBox1.AppendText("\n" + "The " + mob.Name + " is the boss in this room.");
                    }
                }
            }
            else
            {
                MessageBox.Show("You cannot go that way. Choose another path");
            }
        }
        private void GoEast(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerEast != -1)
            {
                Movement.Moving(Enviroment.Rooms[Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerEast]);
                richTextBox1.AppendText("\n" + Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].Name);
                richTextBox1.AppendText("\n" + Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].Description);
                if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].RoomMob != null)
                {

                    if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].MobsRoom.Tracker != 105)
                    {
                        Attack.Enabled = true;
                        Random rand = new Random();
                        int spawnMob = rand.Next(0, 5);
                        mob = new Mob(Enviroment.Mobs[spawnMob]);
                        richTextBox3.Text = $"Name: {mob.Name} \n" +
                                            $"Attack Damage: {mob.AttackDamage} \n" +
                                            $"Armor: {mob.Armor}";
                        string exits = "\nExits available: ";
                        List<string> trueExits = new List<string>();
                        if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerNorth != -1)
                            trueExits.Add("north");
                        if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerEast != -1)
                            trueExits.Add("east");
                        if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerSouth != -1)
                            trueExits.Add("south");
                        if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerWest != -1)
                            trueExits.Add("west");
                        if (trueExits.Count == 1)
                            exits += trueExits[0] + " ";
                        else
                        {
                            for (int i = 0; i < trueExits.Count; i++)
                            {
                                exits += trueExits[i];
                                if (i < trueExits.Count - 1)
                                    exits += ", ";
                            }
                        }
                        richTextBox1.AppendText("\n" + exits);

                        richTextBox1.AppendText("\n" + "There is a " + mob.Name + " lurking in your view of the room.");

                    }
                    else
                    {
                        mob = new Mob(Enviroment.Mobs[5]);
                        richTextBox1.AppendText("\n" + "The " + mob.Name + " is the boss in this room.");
                    }
                }
            }
            else
            {
                MessageBox.Show("You cannot go that way. Choose another path");
            }
        }
        private void GoWest(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerWest != -1)
            {
                Movement.Moving(Enviroment.Rooms[Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerWest]);
               
                richTextBox1.AppendText("\n" + Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].Description);
                if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].RoomMob != null)
                {
                    if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].MobsRoom.Tracker != 105)
                    {
                        Attack.Enabled = true;
                        Random rand = new Random();
                        int spawnMob = rand.Next(0, 5);
                        mob = new Mob(Enviroment.Mobs[spawnMob]);
                        richTextBox3.Text = $"Name: {mob.Name} \n" +
                                            $"Attack Damage: {mob.AttackDamage} \n" +
                                            $"Armor: {mob.Armor}";
                        string exits = "\nExits available: ";
                        List<string> trueExits = new List<string>();
                        if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerNorth != -1)
                            trueExits.Add("north");
                        if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerEast != -1)
                            trueExits.Add("east");
                        if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerSouth != -1)
                            trueExits.Add("south");
                        if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerWest != -1)
                            trueExits.Add("west");
                        if (trueExits.Count == 1)
                            exits += trueExits[0] + " ";
                        else
                        {
                            for (int i = 0; i < trueExits.Count; i++)
                            {
                                exits += trueExits[i];
                                if (i < trueExits.Count - 1)
                                    exits += ", ";
                            }
                        }
                        richTextBox1.AppendText("\n" + exits);
                        richTextBox1.AppendText("\n" + "There is a " + mob.Name + " lurking in your view of the room.");
                    }
                    else
                    {
                        mob = new Mob(Enviroment.Mobs[5]);
                        richTextBox1.AppendText("\n" + "The " + mob.Name + " is the boss in this room.");
                    }
                }
            }
            else
            {
                MessageBox.Show("You cannot go that way. Choose another path");
            }
        }
        private void GoSouth(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            

            richTextBox3.Text = $"Name: {mob.Name} \n" +
                                            $"Attack Damage: {mob.AttackDamage} \n" +
                                            $"Armor: {mob.Armor}";
            if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerSouth != -1)
            {
                Movement.Moving(Enviroment.Rooms[Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerSouth]);
                
                richTextBox1.AppendText("\n" + Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].Description);
                if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].RoomMob != null)
                {

                    if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].MobsRoom.Tracker != 105)
                    {
                        Attack.Enabled = true;
                        Random rand = new Random();
                        int spawnMob = rand.Next(0, 5);
                        mob = new Mob(Enviroment.Mobs[spawnMob]);
                        richTextBox3.Text = $"Name: {mob.Name} \n" +
                                            $"Attack Damage: {mob.AttackDamage} \n" +
                                            $"Armor: {mob.Armor}";
                        string exits = "\nExits available: ";
                        List<string> trueExits = new List<string>();
                        if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerNorth != -1)
                            trueExits.Add("north");
                        if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerEast != -1)
                            trueExits.Add("east");
                        if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerSouth != -1)
                            trueExits.Add("south");
                        if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerWest != -1)
                            trueExits.Add("west");
                        if (trueExits.Count == 1)
                            exits += trueExits[0] + " ";
                        else
                        {
                            for (int i = 0; i < trueExits.Count; i++)
                            {
                                exits += trueExits[i];
                                if (i < trueExits.Count - 1)
                                    exits += ", ";
                            }
                        }
                        richTextBox1.AppendText("\n" + exits);
                        richTextBox1.AppendText("\n" + "There is a " + mob.Name + " lurking in your view of the room.");
                    }
                    else
                    {
                        mob = new Mob(Enviroment.Mobs[5]);
                        richTextBox1.AppendText("\n" + "The " + mob.Name + " is the boss in this room.");
                    }
                }
            }
            else
            {
                MessageBox.Show("You cannot go that way. Choose another path");
            }
        }

        #endregion

        #region Attack Button
        private void ShowAttack(object sender, EventArgs e)
        {
            #region Setting Player HP Bar visuals
            
            int mobPreA = Combat.BuildMobCombat().AttackDamage;
            
            int mobD = mobPreA - myChar.Armor;
            double percOfPlayerHp = (mobD / double.Parse(Enviroment.playerList[4])) * 100;

            
            playerHpBar = playerHpBar - mobD;
            if (progressBar2.Value != 0)
            {
                try
                {
                    progressBar1.Value = playerHpBar;
                }
                catch (Exception ex)
                {
                    progressBar1.Value = 0;
                    MessageBox.Show("YOU ARE DEAD");
                }
            }
            #endregion
            
            #region Setting Mob HP Bar visuals
            int mobA = Combat.BuildMobCombat().Armor;
            
            int playerD = Combat.BuildPlayerCombat(int.Parse(Enviroment.playerList[3])).Damage - mobA;
            double mobHp = Combat.BuildMobCombat().Health;
            
            double percOfMobHp = (playerD / mobHp) * 100;

            
            mobHpBar = mobHpBar - playerD;
            try
            {
                progressBar2.Value = mobHpBar;
            }
            catch(Exception ex)
            {
                progressBar2.Value = 0;
                MessageBox.Show("MOB IS DEAD");
            }
            #endregion

        }

        #endregion

        #region DisplayMovement
        public void ShowCurrentLocation(object sender, EventArgs e)
        {

            richTextBox1.AppendText("\n" + $"Current Room: " + Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].Name);
            if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].Description != "")
            {
                richTextBox1.AppendText(Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].Description);
            }

            string exits = "\nExits available: ";
            List<string> trueExits = new List<string>();
            if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerNorth != -1)
                trueExits.Add("north");
            if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerEast != -1)
                trueExits.Add("east");
            if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerSouth != -1)
                trueExits.Add("south");
            if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].TrackerWest != -1)
                trueExits.Add("west");
            if (trueExits.Count == 1)
                exits += trueExits[0] + " ";
            else
            {
                for (int i = 0; i < trueExits.Count; i++)
                {
                    exits += trueExits[i];
                    if (i < trueExits.Count - 1)
                        exits += ", ";
                }
            }
            richTextBox1.AppendText("\n" + exits);


            if (Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].RoomMob != null)
            {
                

                foreach (Mob mob in Enviroment.Rooms[ClassLibrary.Player.CurrentLocation].RoomMob)
                {
                    if (mob.Tracker != 105)
                    {
                        ClassLibrary.Player.CurrentMob = mob;
                        richTextBox1.AppendText("\n" + "There is a " + mob.Name + " lurking in your view of the room.");

                        
                        mob.Armor = Combat.BuildMobCombat().Armor;
                        mob.AttackDamage = Combat.BuildMobCombat().AttackDamage;

                        richTextBox3.Text = $"Name: {mob.Name} \n" +
                                                        $"Attack Damage: {Combat.BuildMobCombat().AttackDamage} \n" +
                                                        $"Armor: {Combat.BuildMobCombat().Armor}";


                    }
                    else
                    {
                        ClassLibrary.Player.CurrentMob = mob;
                        richTextBox1.AppendText("\n" + "The " + mob.Name + " is the boss in this room.");
                        
                        richTextBox3.Text = $"Name: {mob.Name} \n" +
                                            $"Attack Damage: {mob.AttackDamage} \n" +
                                            $"Armor: {mob.Armor}";


                    }
                    
                    #region Mob Stats Text



                    #endregion
                }
            }
        }

        #endregion

        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void PlayerStatsPanel(object sender, EventArgs e)
        {
            
        }
        private void MobStatsPanel(object sender, EventArgs e)
        {

        }
        private void InventoryPanel(object sender, EventArgs e)
        {

        }
    }
}
