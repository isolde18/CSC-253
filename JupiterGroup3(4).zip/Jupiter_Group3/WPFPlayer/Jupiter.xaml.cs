﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ClassLibrary;

namespace WPFPlayer
{
    /// <summary>
    /// Interaction logic for Jupiter.xaml
    /// </summary>
    public partial class Jupiter : Window
    {
        Player myPlayer;
        Mob mob;
        public Jupiter()
        {
            InitializeComponent();
            StreamBuilder.Build();
            MainWindow mainWindow = new MainWindow();
            roomTrackerText.Text = Enviroment.Rooms[0].Name;
            descriptTextBox.Text = Enviroment.Rooms[0].Description;

            mainWindow.healthTextBox.Text = textDisplayHealth.Text;
            mainWindow.manaTextBox.Text = textDisplayMana.Text;
            mainWindow.classTextBox.Text = textDisplayClass.Text;
            mainWindow.raceTextBox.Text = textDisplayRace.Text;
        }

        private void northButton_Click(object sender, RoutedEventArgs e)
        {
            if (Enviroment.Rooms[Player.CurrentLocation].TrackerNorth != -1)
            {
                Movement.Moving(Enviroment.Rooms[Enviroment.Rooms[Player.CurrentLocation].TrackerNorth]);
                roomTrackerText.Text = Enviroment.Rooms[Player.CurrentLocation].Name;
                descriptTextBox.Text = Enviroment.Rooms[Player.CurrentLocation].Description;
                string exits = "\nExits available: ";
                List<string> trueExits = new List<string>();
                if (Enviroment.Rooms[Player.CurrentLocation].TrackerNorth != -1)
                    trueExits.Add("north");
                if (Enviroment.Rooms[Player.CurrentLocation].TrackerEast != -1)
                    trueExits.Add("east");
                if (Enviroment.Rooms[Player.CurrentLocation].TrackerSouth != -1)
                    trueExits.Add("south");
                if (Enviroment.Rooms[Player.CurrentLocation].TrackerWest != -1)
                    trueExits.Add("west");
                if (trueExits.Count == 1)
                    exits += trueExits[0] + " ";
                else
                {
                    for (int i = 0; i < trueExits.Count; i++)
                    {
                        exits += trueExits[i];
                        if (i < trueExits.Count - 1)
                            exits += ", ";
                    }
                }
                descriptTextBox.AppendText("\n" + exits);
                if (Enviroment.Rooms[Player.CurrentLocation].RoomMob != null)
                {
                    if (Enviroment.Rooms[Player.CurrentLocation].MobsRoom.Tracker != 105)
                    {
                        Random rand = new Random();
                        int spawnMob = rand.Next(0, 4);
                        mob = new Mob(Enviroment.Mobs[spawnMob]);

                        mobTrackerText.Text = "There is a " + mob.Name + " lurking in your view of the room.";
                    }
                    else
                    {
                        mob = new Mob(Enviroment.Mobs[5]);
                        mobTrackerText.Text = "The " + mob.Name + " is the boss in this room.";
                    }
                }
                
            }
            else
            {
                MessageBox.Show("You cannot go that way. Choose another path");
            }
        }
        private void eastButton_Click(object sender, RoutedEventArgs e)
        {
            if (Enviroment.Rooms[Player.CurrentLocation].TrackerEast != -1)
            {
                Movement.Moving(Enviroment.Rooms[Enviroment.Rooms[Player.CurrentLocation].TrackerEast]);
                roomTrackerText.Text = Enviroment.Rooms[Player.CurrentLocation].Name;
                descriptTextBox.Text = Enviroment.Rooms[Player.CurrentLocation].Description;
                string exits = "\nExits available: ";
                List<string> trueExits = new List<string>();
                if (Enviroment.Rooms[Player.CurrentLocation].TrackerNorth != -1)
                    trueExits.Add("north");
                if (Enviroment.Rooms[Player.CurrentLocation].TrackerEast != -1)
                    trueExits.Add("east");
                if (Enviroment.Rooms[Player.CurrentLocation].TrackerSouth != -1)
                    trueExits.Add("south");
                if (Enviroment.Rooms[Player.CurrentLocation].TrackerWest != -1)
                    trueExits.Add("west");
                if (trueExits.Count == 1)
                    exits += trueExits[0] + " ";
                else
                {
                    for (int i = 0; i < trueExits.Count; i++)
                    {
                        exits += trueExits[i];
                        if (i < trueExits.Count - 1)
                            exits += ", ";
                    }
                }
                descriptTextBox.AppendText("\n" + exits);
                if (Enviroment.Rooms[Player.CurrentLocation].RoomMob != null)
                {
                    if (Enviroment.Rooms[Player.CurrentLocation].MobsRoom.Tracker != 105)
                    {
                        Random rand = new Random();
                        int spawnMob = rand.Next(0, 4);
                        mob = new Mob(Enviroment.Mobs[spawnMob]);

                        mobTrackerText.Text = "There is a " + mob.Name + " lurking in your view of the room.";
                    }
                    else
                    {
                        mob = new Mob(Enviroment.Mobs[5]);
                        mobTrackerText.Text = "The " + mob.Name + " is the boss in this room.";
                    }
                }
            }
            else
            {
                MessageBox.Show("You cannot go that way. Choose another path");
            }
        }
        private void southButton_Click(object sender, RoutedEventArgs e)
        {
            if (Enviroment.Rooms[Player.CurrentLocation].TrackerSouth != -1)
            {
                Movement.Moving(Enviroment.Rooms[Enviroment.Rooms[Player.CurrentLocation].TrackerSouth]);
                roomTrackerText.Text = Enviroment.Rooms[Player.CurrentLocation].Name;
                descriptTextBox.Text = Enviroment.Rooms[Player.CurrentLocation].Description;
                string exits = "\nExits available: ";
                List<string> trueExits = new List<string>();
                if (Enviroment.Rooms[Player.CurrentLocation].TrackerNorth != -1)
                    trueExits.Add("north");
                if (Enviroment.Rooms[Player.CurrentLocation].TrackerEast != -1)
                    trueExits.Add("east");
                if (Enviroment.Rooms[Player.CurrentLocation].TrackerSouth != -1)
                    trueExits.Add("south");
                if (Enviroment.Rooms[Player.CurrentLocation].TrackerWest != -1)
                    trueExits.Add("west");
                if (trueExits.Count == 1)
                    exits += trueExits[0] + " ";
                else
                {
                    for (int i = 0; i < trueExits.Count; i++)
                    {
                        exits += trueExits[i];
                        if (i < trueExits.Count - 1)
                            exits += ", ";
                    }
                }
                descriptTextBox.AppendText("\n" + exits);
                if (Enviroment.Rooms[Player.CurrentLocation].RoomMob != null)
                {
                    if (Enviroment.Rooms[Player.CurrentLocation].MobsRoom.Tracker != 105)
                    {
                        Random rand = new Random();
                        int spawnMob = rand.Next(0, 4);
                        mob = new Mob(Enviroment.Mobs[spawnMob]);

                        mobTrackerText.Text = "There is a " + mob.Name + " lurking in your view of the room.";
                    }
                    else
                    {
                        mob = new Mob(Enviroment.Mobs[5]);
                        mobTrackerText.Text = "The " + mob.Name + " is the boss in this room.";
                    }
                }
            }
            else
            {
                MessageBox.Show("You cannot go that way. Choose another path");
            }
        }
        private void westButton_Click(object sender, RoutedEventArgs e)
        {
            if (Enviroment.Rooms[Player.CurrentLocation].TrackerWest != -1)
            {
                Movement.Moving(Enviroment.Rooms[Enviroment.Rooms[Player.CurrentLocation].TrackerWest]);
                roomTrackerText.Text = Enviroment.Rooms[Player.CurrentLocation].Name;
                descriptTextBox.Text = Enviroment.Rooms[Player.CurrentLocation].Description;
                string exits = "\nExits available: ";
                List<string> trueExits = new List<string>();
                if (Enviroment.Rooms[Player.CurrentLocation].TrackerNorth != -1)
                    trueExits.Add("north");
                if (Enviroment.Rooms[Player.CurrentLocation].TrackerEast != -1)
                    trueExits.Add("east");
                if (Enviroment.Rooms[Player.CurrentLocation].TrackerSouth != -1)
                    trueExits.Add("south");
                if (Enviroment.Rooms[Player.CurrentLocation].TrackerWest != -1)
                    trueExits.Add("west");
                if (trueExits.Count == 1)
                    exits += trueExits[0] + " ";
                else
                {
                    for (int i = 0; i < trueExits.Count; i++)
                    {
                        exits += trueExits[i];
                        if (i < trueExits.Count - 1)
                            exits += ", ";
                    }
                }
                descriptTextBox.AppendText("" + exits);
                if (Enviroment.Rooms[Player.CurrentLocation].RoomMob != null)
                {
                    if (Enviroment.Rooms[Player.CurrentLocation].MobsRoom.Tracker != 105)
                    {
                        Random rand = new Random();
                        int spawnMob = rand.Next(0, 4);
                        mob = new Mob(Enviroment.Mobs[spawnMob]);

                        mobTrackerText.Text = "There is a " + mob.Name + " lurking in your view of the room.";
                    }
                    else
                    {
                        mob = new Mob(Enviroment.Mobs[5]);
                        mobTrackerText.Text = "The " + mob.Name + " is the boss in this room.";
                    }
                }
            }
            else
            {
                MessageBox.Show("You cannot go that way. Choose another path");
            }
        }
        private void attackButton_Click(object sender, RoutedEventArgs e)
        {
            mobTrackerText.Text = Combat.DisplayCombat(Combat.DealPlayerDamage(Combat.BuildPlayerCombat(int.Parse(Enviroment.playerList[3])),
                       Combat.BuildMobCombat()), Combat.DealMobDamage(Combat.BuildPlayerCombat(int.Parse(Enviroment.playerList[3])), Combat.BuildMobCombat()),
                       Combat.PlayerHP(Combat.BuildPlayerCombat(int.Parse(Enviroment.playerList[3])), Combat.DealMobDamage(Combat.BuildPlayerCombat(int.Parse(Enviroment.playerList[3])),
                       Combat.BuildMobCombat())), Combat.MobHP(Combat.BuildMobCombat(), Combat.DealPlayerDamage(Combat.BuildPlayerCombat(int.Parse(Enviroment.playerList[3])), Combat.BuildMobCombat())));
        }
    }
}
