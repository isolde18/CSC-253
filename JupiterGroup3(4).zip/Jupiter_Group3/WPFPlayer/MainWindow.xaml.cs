﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ClassLibrary;

namespace WPFPlayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Player myPlayer;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Player myPlayer = new Player();
            Jupiter jupiter = new Jupiter();
            myPlayer.Class = jupiter.textDisplayClass.Text = classTextBox.Text;
            myPlayer.Race = jupiter.textDisplayRace.Text = raceTextBox.Text;
            myPlayer.Health = StandardMessages.ConvertToInt(jupiter.textDisplayHealth.Text = healthTextBox.Text);
            myPlayer.Mana = StandardMessages.ConvertToInt(jupiter.textDisplayMana.Text = manaTextBox.Text);

            jupiter.Show();
            Close();
        }
    }
}
