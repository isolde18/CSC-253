﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //declare a variable to hold an item read from the file
                string reading_item;

                //declare a StreamReader variable
                StreamReader inputFile;

                //open the file and get a StreamReader object
                inputFile = File.OpenText("RandomNumber.txt");

                //read and display the first line
                reading_item = inputFile.ReadLine();
                Console.WriteLine(reading_item);
                Console.ReadLine();
                //repeat the same for all the lines in the text file
                //close the file
                inputFile.Close();
             }
            catch (Exception ex)
            {
                //Display an exception
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
        }
    }
}
