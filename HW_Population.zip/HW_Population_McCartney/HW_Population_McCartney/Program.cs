﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_Population_McCartney
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write
                ("What is the initial population?");
            int initialPopul = int.Parse(Console.ReadLine());

            Console.Write
                ("Enter the number of days--->");
            int days = int.Parse(Console.ReadLine());
            int finalPopul = initialPopul * days;
            Console.Write(finalPopul);
            Console.Read();

            Console.Write("What is the growth rate?"); // enter the percentage in decimal form
            double growthRate=0.3;
            
            double e=finalPopul * growthRate;
            Console.Write(e);
            Console.Read();
            System.Console.ReadLine();
            Console.WriteLine("____________________________________");
            double growRate;
            Console.Write("Write the growth rate in decimal form: "); // enter the percentage in decimal form
            double.TryParse(Console.ReadLine(), out growRate);
            //the program calculates it and displays the total 
            double finalPop=initialPopul * growRate * days;
            Console.Write(finalPop);
            Console.Read();
            Console.WriteLine("____________________________________");
            //include the for loop for i=<10, where i is the number of days
            for ( days=0;days<11;days++)
            {
                double
                    
                    answer = finalPopul * (growRate * days);
                Console.Write(answer);
                Console.Read();
            }
        }
    }
}
