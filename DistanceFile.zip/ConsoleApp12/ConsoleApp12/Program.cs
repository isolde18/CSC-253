﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp12
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Enter the speed");
            //int speed = int.Parse(Console.ReadLine());
            //Console.WriteLine("Enter the miles");
            //int miles = int.Parse(Console.ReadLine());
            //int distance;
            //distance = miles * speed;
            //Console.WriteLine("This is the distance\n" + distance);
            //Console.ReadLine();
            try
            {
                
                StreamWriter outputFile;
                outputFile = File.CreateText("distance.txt");
                Console.WriteLine("Enter the speed");
                outputFile.WriteLine();
                int speed = int.Parse(Console.ReadLine());
                outputFile.WriteLine(+speed);
                Console.WriteLine("enter the miles");
                int miles = int.Parse(Console.ReadLine());
                outputFile.WriteLine(+miles);
                int distance;
                distance = miles * speed;
                outputFile.WriteLine("This is the distance\n" + distance);
                Console.ReadLine();

                

                //outputFile.WriteLine();
                //outputFile.WriteLine("");

                outputFile.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            //getDistance();
           // getFile();
            //Console.ReadLine();
       // }
        //static void getDistance()
        //{
        //    Console.WriteLine("Enter the speed");
        //    int s = int.Parse(Console.ReadLine());
        //    Console.WriteLine("Enter the miles");
        //    int m = int.Parse(Console.ReadLine());
        //    int d = s * m;
        //    Console.WriteLine("This is the distance\n" + d);
        //}
       // static void getFile()
       // {
            //try
            //{
            //    StreamWriter outputFile;
            //    outputFile = File.CreateText("distance.txt");
            //    outputFile.WriteLine("");
            //    outputFile.WriteLine();
            //    outputFile.WriteLine("");
                
            //    outputFile.Close();
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}

        }
    }
}
    

