﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp10
{
    class Program
    {
        private static readonly int x;

        public static void Main(string[] args)
         {
            string phrase= "Write something: ";
            Console.WriteLine (phrase.Length);
            Console.ReadLine();// counts every single character incl. the white space
            WordsPlus(x);
           //Console.ReadLine();
         }
         public static int  WordsPlus(int num)
         {
            string str = "Write whatever you want";
            string[] tokens = str.Split();
            int x = tokens.Length;// counts only the words in the string
            //string first = tokens[0];
            System.Console.Write(x);
            System.Console.ReadLine();
            return x;
         }
    }
}

