﻿namespace ConsoleApp10
{
    public class input
    {
    }
}