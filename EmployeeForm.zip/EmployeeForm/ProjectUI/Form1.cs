﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lbl_indigo_montoya.Text = "Indigo Montoya";
        }

        private void lbl_indigo_montoya_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        //private void pictureBox1_Click(object sender, EventArgs e)
        //{

        //}

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        //private void pictureBox2_Click(object sender, EventArgs e)
        //{
        //    // Show the Open File dialog. If the user clicks OK, load the
        //    // picture that the user chose.
        //    if (openFileDialog1.ShowDialog() == DialogResult.OK)
        //    {
        //        pictureBox2.Load(openFileDialog1.FileName);
        //    }
        //}

        private void showBtn_Click(object sender, EventArgs e)
        {
            // Show the Open File dialog. If the user clicks OK, load the
            // picture that the user chose.
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox.Load(openFileDialog1.FileName);
            }
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            //Clear the picture
            pictureBox.Image = null;
        }
        
        private void backgroundBtn_Click(object sender, EventArgs e)
        {
            // Show the color dialog box. If the user clicks OK, change the
            // PictureBox control's background to the color the user chose.
            if (colorDialog1.ShowDialog() == DialogResult.OK)
                pictureBox2.BackColor = colorDialog1.Color;
        }

        private void closeBtn_Click(object sender, EventArgs e)
        {
            // Close the form.
            this.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        //private void pictureBox1_Click(object sender, EventArgs e)
        //{
        //    // Show the Open File dialog. If the user clicks OK, load the
        //    // picture that the user chose.
        //    if (openFileDialog1.ShowDialog() == DialogResult.OK)
        //    {
        //        pictureBox1.Load(openFileDialog1.FileName);
        //    }
        //}

        private void employeeBtn_Click(object sender, EventArgs e)
        {
            lbl_indigo_montoya.Text = "Indigo Montoya";
        }

        private void color_backgroundBtnClick(object sender, EventArgs e)
        {
            // Show the color dialog box. If the user clicks OK, change the
            // PictureBox control's background to the color the user chose.
            if (colorDialog1.ShowDialog() == DialogResult.OK)
                pictureBox.BackColor = colorDialog1.Color;
        }

        private void pictureBox_Click(object sender, EventArgs e)
        {
            // Show the Open File dialog. If the user clicks OK, load the
            // picture that the user chose.
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox.Load(openFileDialog1.FileName);
            }
        }
    }
}
