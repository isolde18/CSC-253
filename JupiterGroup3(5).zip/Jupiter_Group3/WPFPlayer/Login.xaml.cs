﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Configuration;

namespace WPFPlayer
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            var conStr = System.Configuration.ConfigurationManager.ConnectionStrings["WPFPlayer.Properties.Settings.PlayerDBConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);

            string strQuery = "Select Password from Player";

            con.Open();

            SqlCommand cmd = new SqlCommand(strQuery, con);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds);

            con.Close();



            string strPassword;

            string strPassText;


            strPassText = passTextBox.Text;

            if (ds.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {

                    strPassword = Convert.ToString(ds.Tables[0].Rows[i]["Password"].ToString());

                    if (strPassText == strPassword)
                    {

                        Jupiter jupiter = new Jupiter();
                        jupiter.Show();
                    }
                    else
                    {

                        MessageBox.Show("Incorrect Password!");
                    }
                }
            }
        }

        private void CreateAccount_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
        }
    }

}
