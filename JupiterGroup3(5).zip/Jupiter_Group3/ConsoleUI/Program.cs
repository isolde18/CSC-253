﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

namespace ConsoleUI
{
    class Program
    {
        // Je'Von implemented the menu and classes
        static void Main(string[] args)
        {
            
            // Create variable for user input
            int userChoice = 0;
            // Display start menu
            Console.WriteLine(StandardMessages.StartMenu());
            // Set userChoice to the return value of validation method
            userChoice = DecisionStructure.MenuChoiceValidation(userChoice, 3);

            // Decide what to do based on userChoice option
            DecisionStructure.StartMenuChoice(userChoice);

            Console.ReadLine();
        }
    }
            
}
