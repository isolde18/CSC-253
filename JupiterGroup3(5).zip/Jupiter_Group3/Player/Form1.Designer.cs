﻿using System;
using System.Windows.Forms;

namespace Player
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.North = new System.Windows.Forms.Button();
            this.South = new System.Windows.Forms.Button();
            this.East = new System.Windows.Forms.Button();
            this.West = new System.Windows.Forms.Button();
            this.PlayerStats = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.MobStats = new System.Windows.Forms.TabPage();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.Attack = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.PlayerStats.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.MobStats.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // North
            // 
            this.North.Location = new System.Drawing.Point(587, 410);
            this.North.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.North.Name = "North";
            this.North.Size = new System.Drawing.Size(100, 28);
            this.North.TabIndex = 0;
            this.North.Text = "North";
            this.North.UseVisualStyleBackColor = true;
            this.North.Click += new System.EventHandler(this.GoNorth);
            // 
            // South
            // 
            this.South.Location = new System.Drawing.Point(587, 471);
            this.South.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.South.Name = "South";
            this.South.Size = new System.Drawing.Size(100, 28);
            this.South.TabIndex = 1;
            this.South.Text = "South";
            this.South.UseVisualStyleBackColor = true;
            this.South.Click += new System.EventHandler(this.GoSouth);
            // 
            // East
            // 
            this.East.Location = new System.Drawing.Point(695, 446);
            this.East.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.East.Name = "East";
            this.East.Size = new System.Drawing.Size(100, 28);
            this.East.TabIndex = 2;
            this.East.Text = "East";
            this.East.UseVisualStyleBackColor = true;
            this.East.Click += new System.EventHandler(this.GoEast);
            // 
            // West
            // 
            this.West.Location = new System.Drawing.Point(479, 446);
            this.West.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.West.Name = "West";
            this.West.Size = new System.Drawing.Size(100, 28);
            this.West.TabIndex = 3;
            this.West.Text = "West";
            this.West.UseVisualStyleBackColor = true;
            this.West.Click += new System.EventHandler(this.GoWest);
            // 
            // PlayerStats
            // 
            this.PlayerStats.Controls.Add(this.tabPage1);
            this.PlayerStats.Controls.Add(this.MobStats);
            this.PlayerStats.Controls.Add(this.tabPage2);
            this.PlayerStats.Location = new System.Drawing.Point(16, 15);
            this.PlayerStats.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.PlayerStats.Name = "PlayerStats";
            this.PlayerStats.SelectedIndex = 0;
            this.PlayerStats.Size = new System.Drawing.Size(257, 388);
            this.PlayerStats.TabIndex = 4;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.richTextBox2);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Size = new System.Drawing.Size(249, 359);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Player Stats";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(0, 0);
            this.richTextBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(245, 355);
            this.richTextBox2.TabIndex = 0;
            this.richTextBox2.Text = "";
            // 
            // MobStats
            // 
            this.MobStats.Controls.Add(this.richTextBox3);
            this.MobStats.Location = new System.Drawing.Point(4, 25);
            this.MobStats.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MobStats.Name = "MobStats";
            this.MobStats.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MobStats.Size = new System.Drawing.Size(249, 359);
            this.MobStats.TabIndex = 1;
            this.MobStats.Text = "Mob Stats";
            this.MobStats.UseVisualStyleBackColor = true;
            // 
            // richTextBox3
            // 
            this.richTextBox3.Location = new System.Drawing.Point(0, 0);
            this.richTextBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.Size = new System.Drawing.Size(245, 355);
            this.richTextBox3.TabIndex = 7;
            this.richTextBox3.Text = "";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.richTextBox4);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Size = new System.Drawing.Size(249, 359);
            this.tabPage2.TabIndex = 2;
            this.tabPage2.Text = "Inventory";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // richTextBox4
            // 
            this.richTextBox4.Location = new System.Drawing.Point(1, 4);
            this.richTextBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.Size = new System.Drawing.Size(243, 350);
            this.richTextBox4.TabIndex = 0;
            this.richTextBox4.Text = "";
            // 
            // Attack
            // 
            this.Attack.Enabled = false;
            this.Attack.Location = new System.Drawing.Point(897, 446);
            this.Attack.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Attack.Name = "Attack";
            this.Attack.Size = new System.Drawing.Size(100, 28);
            this.Attack.TabIndex = 5;
            this.Attack.Text = "Attack";
            this.Attack.UseVisualStyleBackColor = true;
            this.Attack.Click += new System.EventHandler(this.ShowAttack);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Font = new System.Drawing.Font("Modern No. 20", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(31, 47);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(567, 280);
            this.richTextBox1.TabIndex = 7;
            this.richTextBox1.Text = "";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.richTextBox1);
            this.groupBox1.Font = new System.Drawing.Font("Modern No. 20", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(299, 30);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(627, 373);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Jupiter";
            // 
            // progressBar1
            // 
            this.progressBar1.BackColor = System.Drawing.Color.Red;
            this.progressBar1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.progressBar1.Location = new System.Drawing.Point(0, 23);
            this.progressBar1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.progressBar1.Size = new System.Drawing.Size(247, 28);
            this.progressBar1.TabIndex = 9;
            this.progressBar1.Value = 100;
            this.progressBar1.Click += new System.EventHandler(this.progressBar1_Click);
            // 
            // progressBar2
            // 
            this.progressBar2.Location = new System.Drawing.Point(0, 23);
            this.progressBar2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(247, 28);
            this.progressBar2.TabIndex = 10;
            this.progressBar2.Value = 100;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.progressBar1);
            this.groupBox2.Location = new System.Drawing.Point(23, 410);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(251, 64);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Player HP";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.progressBar2);
            this.groupBox3.Location = new System.Drawing.Point(23, 481);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Size = new System.Drawing.Size(251, 68);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Mob HP";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Attack);
            this.Controls.Add(this.PlayerStats);
            this.Controls.Add(this.West);
            this.Controls.Add(this.East);
            this.Controls.Add(this.South);
            this.Controls.Add(this.North);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Jupiter";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.PlayerStats.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.MobStats.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button North;
        private System.Windows.Forms.Button South;
        private System.Windows.Forms.Button East;
        private System.Windows.Forms.Button West;
        private System.Windows.Forms.TabControl PlayerStats;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage MobStats;
        private System.Windows.Forms.Button Attack;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private RichTextBox richTextBox2;
        private RichTextBox richTextBox3;
        private RichTextBox richTextBox4;
    }
}

