﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public static class CurrentLocation
    {
        public static void ShowCurrentLocation()
        {
            Console.WriteLine($"Current Room: " + Enviroment.Rooms[Player.CurrentLocation].Name);

            if (Enviroment.Rooms[Player.CurrentLocation].Description != "")
            {
                Console.WriteLine(Enviroment.Rooms[Player.CurrentLocation].Description);
            }

            string exits = "\nExits available: ";
            List<string> trueExits = new List<string>();
            if (Enviroment.Rooms[Player.CurrentLocation].TrackerNorth != -1)
                trueExits.Add("north");
            if (Enviroment.Rooms[Player.CurrentLocation].TrackerEast != -1)
                trueExits.Add("east");
            if (Enviroment.Rooms[Player.CurrentLocation].TrackerSouth != -1)
                trueExits.Add("south");
            if (Enviroment.Rooms[Player.CurrentLocation].TrackerWest != -1)
                trueExits.Add("west");
            if (trueExits.Count == 1)
                exits += trueExits[0] + " ";
            else
            {
                for (int i = 0; i < trueExits.Count; i++)
                {
                    exits += trueExits[i];
                    if (i < trueExits.Count - 1)
                        exits += ", ";
                }
            }
            Console.WriteLine(exits);

            if (Enviroment.Rooms[Player.CurrentLocation].RoomMob != null)
            {
                foreach (Mob mob in Enviroment.Rooms[Player.CurrentLocation].RoomMob)
                {
                    if (mob.Tracker != 105)
                    {
                        Player.CurrentMob = mob;
                        Console.WriteLine("There is a " + mob.Name + " lurking in your view of the room.");
                    }
                    else
                    {
                        Player.CurrentMob = mob;
                        Console.WriteLine("The " + mob.Name + " is the boss in this room.");
                    }
                }
            }
        }
    }
}
