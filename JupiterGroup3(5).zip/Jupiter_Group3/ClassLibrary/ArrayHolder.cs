﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class ArrayHolder
    {
        public static Array RarityArray()
        {
            string[] rarityArray = { "Common", "Uncommon", "Rare", "Legendary", "Mythic" };
            return rarityArray;
        }
        public static Array ItemDescriptionArray()
        {
            string[] itemArray = { "Amulet of Resurrection (Rare,Usable: All Classes)", "Amulet of Vitality (Uncommon, Usable: All Classes)",
             "Ring of Mana (Common,Usable: Templar,Rogue,Archmage)", "Ring of Stamina (Common, Usable: Dwarf)", "Max Repel (Unommon, Usable: All Classes)",
             "Invisibility Cape (Uncommon, Usable: All Classes)","Magic Ball (Common, Usable: All Classes)"}; // Silvia added more items
            foreach (string item in itemArray)
            {
                Console.WriteLine(item);
            }
            return itemArray;
        }
        public static Array MobArray()
        {
            string[] mobArray = { "Wolf", "Goblin", "Goblin Mage", "Hobgoblin", "Goblin Commander", "Goblin King" };
            foreach (string mob in mobArray)
            {
                Console.WriteLine(mob);
            }
            return mobArray;
        }
        public static Array StatArray()
        {
            string[] statArray = { "Health", "Mana", "Dexterity", "Speed", "Armor", "Attack", "Vitality", "Wisdom" };
            foreach (string stat in statArray)
            {
                Console.WriteLine(stat);
            }
            return statArray;
        }
        public static Array AbilityArray()
        {
            string[] abilityArray = { "Charge (Usable: Dwarf, Warrior)", "God's Might(Usable: Templar)", "Backstab (Usable: Rogue)", "Firebolt(Usable: Archmage, Mage)" };
            foreach (string ability in abilityArray)
            {
                Console.WriteLine(ability);
            }
            return abilityArray;
        }
        public static Array WeaponArray()
        {
            string[] weaponArray = { "Rusty Battleaxe (Common,One-handed,Usable: Dwarf, Templar)", "Rusty Claymore (Common,Two-handed,Usable: Dwarf, Templar)",
                "Worn Shield (Common,Usable:(Only usable with One-handed weapons) Dwarf, Templar)","Rusty Assassin Dagger (Common,One-handed,Usable: Rogue)",
                "Splintered Staff (Common,Two-handed,Usable: Archmage, Mage)" };
            foreach (string weapon in weaponArray)
            {
                Console.WriteLine(weapon);
            }
            return weaponArray;
        }
        public static Array ClassArray()
        {
            string[] classArray = { "Warrior", "Mage", "Dwarf", "Templar", "Archmage", "Rogue" };
            foreach (string classes in classArray)
            {
                Console.WriteLine(classes);
            }
            return classArray;
        }
        public static Array RoomArray()
        {
            string[] roomArray = { "Dungeon Entrance", "Wolf Den", "Eerie Room", "Treasure Room", "Cave Room", "Ancient Room", "Hologram Room", //Silvia added more rooms
            "Maze Room", "Secret Room", "Boss Room"};
            foreach (string room in roomArray)
            {
                Console.WriteLine(room);
            }
            return roomArray;
        }
        public static Array PotionArray()
        {
            string[] potionArray = { "Potion of Health", "Potion of Mana" };
            foreach (string potion in potionArray)
            {
                Console.WriteLine(potion);
            }
            return potionArray;
        }
        public static Array TreasureArray()
        {
            string[] treasureArray = { "Gold", "Silver", "Ruby", "Emerald", "Saphire", "Diamond", "Golden Goblin Eye" };
            foreach (string treasure in treasureArray)
            {
                Console.WriteLine(treasure);
            }
            return treasureArray;
        }
    }
}
