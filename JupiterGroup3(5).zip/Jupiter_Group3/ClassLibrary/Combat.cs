﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Combat
    {
        public static Mob BuildMobCombat()
        {
            Mob myMob = new Mob();
            myMob.Armor = 10;
            myMob.AttackDamage = 20;
            myMob.Health = 150;
            myMob.Name = "";
            return myMob;
        }
        public static Player BuildPlayerCombat(int health)
        {
            Player myPlayerCombat = new Player();
            myPlayerCombat.Damage = 30;
            myPlayerCombat.Armor = 10;
            myPlayerCombat.Health = health;

            return myPlayerCombat;
        }
        public static int DealPlayerDamage(Player myCharacter, Mob myMob)
        {
            int playerDamageDealt = myCharacter.Damage - myMob.Armor;
            return playerDamageDealt;
        }
        public static int DealMobDamage(Player myCharacter, Mob myMob)
        {
            int mobDamageDealt = myMob.AttackDamage - myCharacter.Armor;
            return mobDamageDealt;
        }
        public static int PlayerHP(Player myCharacter, int damage)
        {
            int playerHP = myCharacter.Health - damage;
            return playerHP;
        }
        public static int MobHP(Mob myMob, int damage)
        {
            int mobHP = myMob.Health - damage;
            return mobHP;
        }

        public static string DisplayCombat(int pDeal, int mDeal, int pHp, int mHp)
        {
            return $"Player damage dealt: {pDeal}\n" +
                    $"Mob damage dealt: {mDeal} \n" +
                    $"Player HP: {pHp}\n" +
                    $"Mob HP: {mHp}";
        }

    }
}
