﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Mob : Character
    {
        // Fields
        private int _tracker;
        private int _attackdmg;
        private Mob mob;

        // Default Constructor
        public Mob()
        {
            AttackDamage = 0;
        }

        // Custom Constructor
        public Mob(int tracker, string name, int health, int armorpts, int attackDamage)
            : base(name, health, armorpts)
        {
            AttackDamage = attackDamage;
            Tracker = tracker;
        }
        // Properties
        public int AttackDamage
        {
            get
            {
                return _attackdmg;
            }
            set
            {
                _attackdmg = value;
            }
        }
        public int Tracker { get { return _tracker; } set { _tracker = value; } }
        
        public Mob(Mob mobCopy) : base(mobCopy.Name, mobCopy.Health, mobCopy.Armor)
        {
            Name = mobCopy.Name;
            Health = mobCopy.Health;
            Armor = mobCopy.Armor;
        }
    }
}
