﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public static class PlayerMovement
    {
        public static void MoveTo(string verb)
        {
            Movement.MoveToDirection(verb);
            CurrentLocation.ShowCurrentLocation();
            if (Movement.canMove == false)
            {
                Console.WriteLine("You can not go " + verb);
            }
        }
        public static void ToAttack(ref List<Mob> mobs, Player myPlayer)
        {

            Console.WriteLine(StandardMessages.CombatDealt(Combat.DealPlayerDamage(Combat.BuildPlayerCombat(myPlayer.Health), Combat.BuildMobCombat()), Combat.DealMobDamage(Combat.BuildPlayerCombat(myPlayer.Health), Combat.BuildMobCombat()), Combat.PlayerHP(Combat.BuildPlayerCombat(myPlayer.Health), Combat.DealMobDamage(Combat.BuildPlayerCombat(myPlayer.Health), Combat.BuildMobCombat())), Combat.MobHP(Combat.BuildMobCombat(), Combat.DealPlayerDamage(Combat.BuildPlayerCombat(myPlayer.Health), Combat.BuildMobCombat()))));

        }
    }
}
