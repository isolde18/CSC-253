﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Configuration;
using System.Data.SqlClient;

namespace ClassLibrary
{
    public static class StreamBuilder
    {
        public static void Build()
        {
            //Text file for mobs
            #region Adding Mobs
            StreamReader output = File.OpenText(@"../../../ClassLibrary/TextFiles/Mobs.txt");
            {
                while (!output.EndOfStream)
                {
                    int tracker = int.Parse(output.ReadLine());
                    string name = output.ReadLine();
                    int health = int.Parse(output.ReadLine());
                    int armorpts = int.Parse(output.ReadLine());
                    int attackDamage = int.Parse(output.ReadLine());
                    Enviroment.Mobs.Add(new Mob(tracker, name, health, armorpts, attackDamage));
                }
            }
            #endregion

            //Text file for Rooms
            #region Adding Rooms
            StreamReader output1 = File.OpenText(@"../../../ClassLibrary/TextFiles/Rooms.txt");
            {
                while (!output1.EndOfStream)
                {
                    string name = output1.ReadLine();
                    string description = output1.ReadLine();
                    int tracker = int.Parse(output1.ReadLine());
                    int north = int.Parse(output1.ReadLine());
                    int east = int.Parse(output1.ReadLine());
                    int south = int.Parse(output1.ReadLine());
                    int west = int.Parse(output1.ReadLine());
                    int monsterTracker = int.Parse(output1.ReadLine());
                    Enviroment.Rooms.Add(new Room(name, description, tracker, north, east, south, west, monsterTracker));
                }
            }
            #endregion

            //Text File for Items
            #region Adding Items
            StreamReader output2 = File.OpenText(@"../../../ClassLibrary/TextFiles/Items.txt");
            {
                while (!output2.EndOfStream)
                {
                    string name = output2.ReadLine();
                    string description = output2.ReadLine();
                    int price = int.Parse(output2.ReadLine());
                    bool equip = bool.Parse(output2.ReadLine());
                    bool usable = bool.Parse(output2.ReadLine());
                    bool craftable = bool.Parse(output2.ReadLine());
                    Enviroment.Items.Add(new Item(name, description, price, equip, usable, craftable));
                }
            }
            #endregion

            //Text File for Weapons
            #region Adding Weapons
            StreamReader output3 = File.OpenText(@"../../../ClassLibrary/TextFiles/Weapons.txt");
            {
                while (!output3.EndOfStream)
                {
                    string name = output3.ReadLine();
                    string description = output3.ReadLine();
                    int price = int.Parse(output3.ReadLine());
                    bool equip = bool.Parse(output3.ReadLine());
                    bool usable = bool.Parse(output3.ReadLine());
                    string type = output3.ReadLine();
                    int damage = int.Parse(output3.ReadLine());
                    Enviroment.Weapons.Add(new Weapon(name, description, price, equip, usable, type, damage));
                }
            }
            #endregion

            //Text File for Treasure
            #region Adding Treasure
            StreamReader output4 = File.OpenText(@"../../../ClassLibrary/TextFiles/Treasure.txt");
            {
                while (!output4.EndOfStream)
                {
                    string name = output4.ReadLine();
                    string description = output4.ReadLine();
                    int price = int.Parse(output4.ReadLine());
                    bool equip = bool.Parse(output4.ReadLine());
                    bool usable = bool.Parse(output4.ReadLine());
                    bool rare = bool.Parse(output4.ReadLine());
                    bool legend = bool.Parse(output4.ReadLine());
                    Enviroment.Treasures.Add(new Treasure(name, description, price, equip, usable, rare, legend)); ;
                }
            }
            #endregion

            //Text File for Potion
            #region Adding Potion
            StreamReader output5 = File.OpenText(@"../../../ClassLibrary/TextFiles/Potion.txt");
            {
                while (!output5.EndOfStream)
                {
                    string name = output5.ReadLine();
                    string description = output5.ReadLine();
                    int price = int.Parse(output5.ReadLine());
                    bool equip = bool.Parse(output5.ReadLine());
                    bool usable = bool.Parse(output5.ReadLine());
                    int healthPoints = int.Parse(output5.ReadLine());
                    int manaPoints = int.Parse(output5.ReadLine());
                    Enviroment.Potions.Add(new Potion(name, description, price, equip, usable, healthPoints, manaPoints));
                }
            }
            #endregion

            //Text File for Player
            #region Adding Player

            try
            {
                StreamReader output6 = File.OpenText(@"../../../ClassLibrary/TextFiles/Player.txt");

                while (!output6.EndOfStream)
                {
                    Enviroment.playerList.Add(output6.ReadLine());

                }
                output6.Close();
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }



            #endregion
        }
    }
}
    
