﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ClassLibrary
{
    public static class Prompt
    {
        public static void PromptCommand(string input)
        {
            string[] commands = input.Split(null);
            string verb = commands[0].ToLower();
            string noun;
            if (commands.Length != 1)
            {
                noun = commands[1];
            }
            else
            {
                noun = "";
                Commands(verb, noun);
            }
        }
        public static void Commands(string verb, string noun)
        {
            
            switch (verb)
            {
                case "info":
                    DecisionStructure.InfoMenu();
                    break;
                case "north":
                    PlayerMovement.MoveTo(verb);
                    break;
                case "east":
                    PlayerMovement.MoveTo(verb);
                    break;
                case "south":
                    PlayerMovement.MoveTo(verb);
                    break;
                case "west":
                    PlayerMovement.MoveTo(verb);
                    break;
                case "attack":
                    try
                    {
                        Player myPlayer = new Player();
                        Mob myMob = new Mob();

                        myPlayer = Combat.BuildPlayerCombat(int.Parse(Enviroment.playerList[3]));
                        

                        Console.WriteLine(Combat.DisplayCombat(Combat.DealPlayerDamage(Combat.BuildPlayerCombat(int.Parse(Enviroment.playerList[3])), Combat.BuildMobCombat()), Combat.DealMobDamage(Combat.BuildPlayerCombat(int.Parse(Enviroment.playerList[3])), Combat.BuildMobCombat()), Combat.PlayerHP(Combat.BuildPlayerCombat(int.Parse(Enviroment.playerList[3])), Combat.DealMobDamage(Combat.BuildPlayerCombat(int.Parse(Enviroment.playerList[3])), Combat.BuildMobCombat())), Combat.MobHP(Combat.BuildMobCombat(), Combat.DealPlayerDamage(Combat.BuildPlayerCombat(int.Parse(Enviroment.playerList[3])), Combat.BuildMobCombat()))));
                        Console.WriteLine();

                        
                        Enviroment.playerList[3] = Convert.ToString(Combat.PlayerHP(Combat.BuildPlayerCombat(int.Parse(Enviroment.playerList[3])), Combat.DealMobDamage(Combat.BuildPlayerCombat(int.Parse(Enviroment.playerList[3])), Combat.BuildMobCombat())));
                        
                    }

                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }
                        break;

            }
        }
    }
}
