﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.ComponentModel;

namespace ClassLibrary
{
    public class DecisionStructure
    {
        // Decides what to do based on userInput in StartMenu
        public static void StartMenuChoice(int choice)
        {
            switch (choice)
            {
                // If user chooses 1, they enter the dungeon
                case 1:
                    EnterDungeon();
                    break;
                // If user chooses 2, display info menu
                case 2:
                    InfoMenu();
                    break;
                // If user chooses 3, exit
                case 3:
                    Console.WriteLine("Goodbye!");
                    break;
            }
        }
        // Display enter dungeon menu
        public static void EnterDungeon()
        {
            Player myPlayer = new Player();
            string returnPlayer;
            StreamBuilder.Build();
            Console.WriteLine("Welcome to Jupiter");
            Console.WriteLine("-------------------------");

            Console.WriteLine("Are you a returning player?");
            returnPlayer = Console.ReadLine().ToUpper();
            if (returnPlayer == "NO" || returnPlayer == "N")
            {
                
                myPlayer = BuildPlayer.BuildAPlayer(myPlayer);
            }
            else if (returnPlayer == "YES" || returnPlayer == "Y")
            {
                try
                {
                    StreamReader outputFile;
                    outputFile = File.OpenText(@"../../../ClassLibrary/TextFiles/Player.txt");
                    
                    Console.WriteLine("Please Enter your password: ");
                    string passAtt = Console.ReadLine();
                    while (passAtt != outputFile.ReadLine())
                    {
                        outputFile = File.OpenText(@"../../../ClassLibrary/TextFiles/Player.txt");
                        Console.WriteLine("ERROR: Password incorrect! Please try again!");
                        Console.WriteLine("Please Enter your password: ");
                        passAtt = Console.ReadLine();
                    }

                    outputFile.Close();
                    myPlayer.Class = Enviroment.playerList[1];
                    myPlayer.Race = Enviroment.playerList[2];
                    myPlayer.Health = int.Parse(Enviroment.playerList[3]);
                    myPlayer.Mana = int.Parse(Enviroment.playerList[4]);

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }
            Console.WriteLine(StandardMessages.ShowPlayer(myPlayer));

            bool exit = false;

            CurrentLocation.ShowCurrentLocation();

            while (true)
            {
                string input = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(input))
                {
                    continue;
                }
                string commandInput = input.ToLower();
                if (input == "exit")
                {
                    Console.WriteLine("Goodbye");
                    exit = true;
                    break;
                }
                TypeCommand(input, myPlayer);
            }
        }
        private static void TypeCommand(string input, Player myPlayer)
        {
            Prompt.PromptCommand(input);
            Console.WriteLine("");
        }
        // Display Info Menu
        public static void InfoMenu()
        {
            bool exit = false;
            do
            {
                Console.WriteLine(StandardMessages.InfoMenu());
                switch (Console.ReadLine())
                {
                    case "1":
                        ArrayHolder.ClassArray();
                        Console.ReadLine();
                        break;
                    case "2":
                        ArrayHolder.RoomArray();
                        Console.ReadLine();
                        break;
                    case "3":
                        ArrayHolder.PotionArray();
                        Console.ReadLine();
                        break;
                    case "4":
                        ArrayHolder.TreasureArray();
                        Console.ReadLine();
                        break;
                    case "5":
                        ArrayHolder.ItemDescriptionArray();
                        Console.ReadLine();
                        break;
                    case "6":
                        ArrayHolder.WeaponArray();
                        Console.ReadLine();
                        break;
                    case "7":
                        ArrayHolder.AbilityArray();
                        Console.ReadLine();
                        break;
                    case "8":
                        ArrayHolder.MobArray();
                        Console.ReadLine();
                        break;
                    case "9":
                        ArrayHolder.StatArray();
                        Console.ReadLine();
                        break;
                    case "10":
                        Console.WriteLine("Goodbye!");
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid input! Choose again..");
                        break;
                }
            } while (exit == false);
        }
        // Sean Created method to check if user inputs a valid option
        public static int MenuChoiceValidation(int choice, int max)
        {
            // Check to see if user inputs an int and that int is between the lowest (always 1) and highest number for choices
            while (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > max)
            {
                // Inform user that input is invalid
                Console.WriteLine(StandardMessages.InputError());
            }
            // Return user input
            return choice;
        }
    }
}
