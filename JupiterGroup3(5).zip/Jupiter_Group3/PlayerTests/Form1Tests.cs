﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Player;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Player.Tests
{
    [TestClass()]
    public class Form1Tests
    {
        [TestMethod()]
        public void ShowCurrentLocationTest()
        {
            Assert.Fail();
        }
    }
}