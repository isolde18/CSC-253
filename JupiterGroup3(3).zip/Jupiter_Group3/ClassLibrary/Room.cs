﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Room
    {
        // Fields
        private string _name;
        private string _description;
        private int _tracker;
        private int _trackerToNorth;
        private int _trackerToEast;
        private int _trackerToSouth;
        private int _trackerToWest;
        private Mob _roomMob;
        // Custom Constructor
        public Room(string name, string description, int tracker, int north, int east, int south, int west, int monsterTracker)
        {
            Name = name;
            Description = description;
            Tracker = tracker;
            TrackerNorth = north;
            TrackerEast = east;
            TrackerSouth = south;
            TrackerWest = west;

            if (monsterTracker != 105)
            {
                if (monsterTracker > -1)
                {
                    Random rand = new Random();
                    int spawnMob = rand.Next(1, 5);
                    MobsRoom = new Mob(Enviroment.Mobs[spawnMob]);
                    RoomMob.Add(MobsRoom);
                }
            }
            else
            {
                RoomMob.Add(Enviroment.MobByTracker(monsterTracker));
            }
        }
        // Properties
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        public string Description
        {
            get
            {
                return _description;
            }
            set
            {
                _description = value;
            }
        }
        public int Tracker
        {
            get
            {
                return _tracker;
            }
            set
            {
                _tracker = value;
            }
        }
        public int TrackerNorth { get { return _trackerToNorth; } set { _trackerToNorth = value; } }
        public int TrackerEast { get { return _trackerToEast; } set { _trackerToEast = value; } }
        public int TrackerSouth { get { return _trackerToSouth; } set { _trackerToSouth = value; } }
        public int TrackerWest { get { return _trackerToWest; } set { _trackerToWest = value; } }
        public List<Mob> RoomMob = new List<Mob>();
        public Mob MobsRoom { get { return _roomMob; } set { _roomMob = value; } }

        
    }
}
