﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Character
    {
        // Fields
        private string _name;
        private int _health;
        private int _armorpts;
        // Default Constructor
        public Character()
        {
            Name = "";
            Health = 0;
            Armor = 0;
        }
        public Character(string name, int health, int armorpts)
        {
            Name = name;
            Health = health;
            Armor = armorpts;
        }
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        public int Health
        {
            get
            {
                return _health;
            }
            set
            {
                _health = value;
            }
        }
        public int Armor
        {
            get
            {
                return _armorpts;
            }
            set
            {
                _armorpts = value;
            }
        }
    }
}
