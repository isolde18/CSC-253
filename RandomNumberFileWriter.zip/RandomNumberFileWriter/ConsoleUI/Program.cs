﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Create an application that writes a series of random
//numbers to a file. Each random number 
//should be in the range of 1 through 100. 
//The application should let the user specify
//how many random numbers the file will hold and 
//should be saved to a user-specific file name.

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                StreamWriter outputFile;
                outputFile = File.CreateText("RandomNumber.txt");
                int randomNumber;
                Random rand = new Random();
                randomNumber = rand.Next(1, 100);
                outputFile.WriteLine("Your random number is " + randomNumber);
                outputFile.Close();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
