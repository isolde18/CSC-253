﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            string sentence = Console.ReadLine();
			string[] words = sentence.Split();
			string word;
			char one;
			string two;
			string[] piglatin = new string[words.Length];
			for (int i = 0; i < words.Length; i++)
			{
				word = words[i];
				one = word[0];
				two = word.Substring(1, word.Length - 1);
				piglatin[i] = two + one + "ay";

			}
			string finall = "";
			for (int ii = 0; ii < words.Length; ii++)
			{

				finall += piglatin[ii] + " ";
			}
			Console.WriteLine(finall);
			Console.ReadLine();
		}

      }

    }


