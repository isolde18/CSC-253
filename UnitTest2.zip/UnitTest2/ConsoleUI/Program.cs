﻿using System;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {


            {
                // info for the user

                HW_Hospital patient1 = new HW_Hospital()
                {
                    _Name = "Indigo Montoya",
                    _Condition = "Is Feeling Good",
                    _Paid = (0.0)
                };

                Console.WriteLine(
                    $"{patient1.Name} : { patient1.Condition}");

                System.Console.Write("How many days did you spend in the hospital: ");
                int days = int.Parse(Console.ReadLine());
                //System.Console.WriteLine(days);

                int hospitalDayCharge = 350;
                //in a return method calculate the total for the given days
                int result = days * hospitalDayCharge;
                System.Console.WriteLine(
                    $"Please pay this amount for hospital stay: {result}");
                 Console.ReadLine();
               

                System.Console.Write("Enter the amount of other charges. If you dont have other charges enter 0: ");
                int other_charges = int.Parse(Console.ReadLine());
                int totalAmount = result + other_charges;
                System.Console.WriteLine(
                    $"Please pay the total amount of {totalAmount} USD for your hospital exspenses! Good Bye!\n");
                Console.ReadLine();


            }

        }
    }
}
