﻿using System;
using System.Dynamic;
using System.Security.Cryptography.X509Certificates;
using UnitTestHospitalCharges;
namespace ConsoleUI
{
   
    
    public class HW_Hospital

    {
        public const string PaidAmountExceedsOwnedAmountMessage = "Paid amount exceeds owned amount";
        public const string PaidAmountLessThanOwnedAmountMessage = "Paid amount is less than owned amount";
        public string _Name;
        public string _Condition;
        public double _Paid;
        // for the unit test to check the valid amount charged
        public HW_Hospital() {}
        
        public HW_Hospital(string Name,string Condition, double Paid)
        {
            _Name = Name;
            _Condition = Condition;
            _Paid = Paid;
        }
        public string Name
        {
            get { return _Name; }
        }
        public string Condition
        {
            get { return _Condition; }
        }
        public double Paid
        {
            get { return _Paid; }
        }

        public void Debit (double amountOwned,double amountPaid)
        {
            if (amountPaid > 350)
            {
                throw new ArgumentOutOfRangeException("amountPaid", amountPaid, PaidAmountExceedsOwnedAmountMessage);
            }

            if (amountPaid < 350)
            {
                throw new ArgumentOutOfRangeException("amountOwned",amountPaid, PaidAmountLessThanOwnedAmountMessage);
            }

            _Paid -= amountOwned; // 
        }
       
    }
    }

