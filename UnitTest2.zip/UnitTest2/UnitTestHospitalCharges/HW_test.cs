using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestHospitalCharges
{
    [TestClass]
    public class HW_test
    {
        public static string PaidAmountLessThanOwnedAmount { get; private set; }

        [TestMethod]
        public void TestMethod1()
        {
            // Arrange

            double amounedPaid = 350;
            double expected = 350;
            HW_test amounedOwned = new HW_test();

            // Act
            amounedOwned.Equals(amounedPaid);

            // Assert
            double actual = amounedPaid;
            Assert.AreEqual(expected, actual, "Passed");
        }

        [TestMethod]

        public void TestMethod2()
        {
            double amounedPaid = 300;
            double expected = 350;
            HW_test amounedOwned = new HW_test();
            // Act 
            amounedPaid.Equals(amounedOwned); //not equal!
            double actual = amounedPaid;
            Assert.AreEqual(expected, actual, "Should fail");

            try
            {
                HW_test hW_test = new HW_test();
            }
            catch (System.ArgumentOutOfRangeException e)
            {
                // Assert
                StringAssert.Contains(e.Message, HW_test.PaidAmountLessThanOwnedAmount);
            }
        }
    }
}            
        

        
    



