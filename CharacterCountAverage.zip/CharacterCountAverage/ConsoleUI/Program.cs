﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Write something: ");
            string phrase=Console.ReadLine();
            Console.WriteLine("You typed these many letters: "+ phrase.Length);
            string[] tokens = phrase.Split();
            int x = tokens.Length;// counts only the words in the string
            System.Console.Write("The number of words is: "+x);
            int aver_letters = phrase.Length / x;
            Console.WriteLine("\nThe average number of letters is: "+ aver_letters);
            Console.ReadLine();
        }
        }
    }

