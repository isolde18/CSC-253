﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

namespace TextAdventre_01_Group3
{
    public class Program
    {
        // Je'Von implemented the menu and classes
        static void Main(string[] args)
        {
            // Create variable for user input
            int userChoice = 0;
            // Display start menu
            Console.WriteLine(StandardMessages.StartMenu());
            // Set userChoice to the return value of validation method
            userChoice = DecisionStructure.MenuChoiceValidation(userChoice, 3);

            // Decide what to do based on userChoice option
            DecisionStructure.StartMenuChoice(userChoice);

            Console.ReadLine();
        }
        // Method  to be called when user chooses attack
        public static void ToAttack(ref List<Mob> mobs, Player myPlayer)
        {

            Console.WriteLine(StandardMessages.CombatDealt(Combat.DealPlayerDamage(Combat.BuildPlayerCombat(myPlayer.Health), Combat.BuildMobCombat()), 
            Combat.DealMobDamage(Combat.BuildPlayerCombat(myPlayer.Health), Combat.BuildMobCombat()), Combat.PlayerHP(Combat.BuildPlayerCombat(myPlayer.Health),
            Combat.DealMobDamage(Combat.BuildPlayerCombat(myPlayer.Health), Combat.BuildMobCombat())), Combat.MobHP(Combat.BuildMobCombat(),
            Combat.DealPlayerDamage(Combat.BuildPlayerCombat(myPlayer.Health), Combat.BuildMobCombat()))));

        }
    }
}
