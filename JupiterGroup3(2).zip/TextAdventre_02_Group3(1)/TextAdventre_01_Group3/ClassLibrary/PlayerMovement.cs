﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public static class PlayerMovement
    {
        public static void MoveTo(string verb)
        {
            Movement.MoveToDirection(verb);
            CurrentLocation.ShowCurrentLocation();
            if (Movement.canMove == false)
            {
                Console.WriteLine("You can not go " + verb);
            }
        }
    }
}
