﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public static class Prompt
    {
        public static void PromptCommand(string input, Player myPlayer)
        {
            string[] commands = input.Split(null);
            string verb = commands[0].ToLower();
            string noun;
            if (commands.Length != 1)
            {
                noun = commands[1];
            }
            else
            {
                noun = "";
            }
        }
        public static void Commands(string verb, string noun)
        {
            switch(verb)
            {
                case "info":
                    DecisionStructure.InfoMenu();
                    break;
                case "north":
                    PlayerMovement.MoveTo(verb);
                    break;
                case "east":
                    PlayerMovement.MoveTo(verb);
                    break;
                case "south":
                    PlayerMovement.MoveTo(verb);
                    break;
                case "west":
                    PlayerMovement.MoveTo(verb);
                    break;
                case "attack":
                    break;
            }
        }
    }
}
