﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class BuildPlayer
    {
        public static Player BuildAPlayer(Player yourPlayer)
        {
            bool error = true;
            do
            {

                Console.WriteLine("What is your player's class?");
                Console.WriteLine("Warrior, Dwarf, Mage, Theif, Templar, Archmage or Rogue");
                yourPlayer.Class = Console.ReadLine();

                Console.WriteLine("What is your player's race?");
                Console.WriteLine("Elf, Human, Undead, Lizard, Ogre, Daemon");
                yourPlayer.Race = Console.ReadLine();

                Console.WriteLine("What would you like to assign your player's health");
                yourPlayer.Health = ConvertToInt(Console.ReadLine());
                if (yourPlayer.Health < 0)
                {
                    error = true;
                    Console.WriteLine("Something is wrong with the health");
                }
                else
                {
                    error = false;
                }
                Console.WriteLine("What would you like to assign your player's mana");
                yourPlayer.Mana = ConvertToInt(Console.ReadLine());
                if (yourPlayer.Mana < 0)
                {
                    error = true;
                    Console.WriteLine("Something is wrong with the mana");
                }
                else
                {
                    error = false;
                }

                Console.WriteLine("What would you like to assign for your player's password\n The password " +
                    "must contain the minimum length of 8 characters,\nat least one upper, one lower letter," +
                    "\none digit, is no longer than 15 and no shorter then 8 characters.");
                int NumberUpperCase(string str)
                {
                    int upperCase = 0;
                    foreach (char ch in str)
                    {
                        if (char.IsUpper(ch))
                        {
                            upperCase++;
                        }
                    }

                    return upperCase;
                }
                int NumberLowerCase(string str)
                {
                    int lowerCase = 0;
                    foreach (char ch in str)
                    {
                        if (char.IsLower(ch))
                        {
                            lowerCase++;
                        }
                    }

                    return lowerCase;
                }

                int NumberDigits(string str)
                {
                    int digits = 0; 
                    foreach (char ch in str)
                    {
                        if (char.IsDigit(ch))
                        {
                            digits++;
                        }
                    }
                    return digits;
                }
                const int MIN_LENGTH = 8;
                const int MAX_LENGTH = 15;
                yourPlayer.Password = Console.ReadLine();
                if (yourPlayer.Password.Length >= MIN_LENGTH && (yourPlayer.Password.Length <= MAX_LENGTH &&
                    NumberUpperCase(yourPlayer.Password) >= 1 &&
                    NumberLowerCase(yourPlayer.Password) >= 1 &&
                    NumberDigits(yourPlayer.Password) >= 1))
                {
                    error = false;
                    Console.WriteLine("The password is valid");
                }
                else
                {
                    error = true;
                    Console.WriteLine("The password does not meet the requirements");
                }
            } while (error == true);


            return yourPlayer;
        }
        public static int ConvertToInt(string input)
        {
            int output = 0;

            if (int.TryParse(input, out output))
            {
                return output;
            }
            else
            {
                output = -1;
                return output;
            }
        }
    }
}

