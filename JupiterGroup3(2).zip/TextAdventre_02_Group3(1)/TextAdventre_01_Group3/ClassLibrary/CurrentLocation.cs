﻿using System;
using System.Collections.Generic;

namespace ClassLibrary
{
    public static class CurrentLocation
    {
        public static void ShowCurrentLocation()
        {
            Console.WriteLine($"Current Room: " + Player.CurrentLocation.Name);

            if(Player.CurrentLocation.Description != "")
            {
                Console.WriteLine(Player.CurrentLocation.Description);
            }

            string exits = "\nExits available: ";
            List<string> trueExits = new List<string>();
            if (Player.CurrentLocation.TrackerNorth != -1)
                trueExits.Add("north");
            if (Player.CurrentLocation.TrackerEast != -1)
                trueExits.Add("east");
            if (Player.CurrentLocation.TrackerSouth != -1)
                trueExits.Add("south");
            if (Player.CurrentLocation.TrackerWest != -1)
                trueExits.Add("west");
            if (trueExits.Count == 1)
                exits += trueExits[0] + " ";
            else
            {
                for (int i = 0; i < trueExits.Count; i++)
                {
                    exits += trueExits[i];
                    if (i < trueExits.Count - 1)
                        exits += ", ";
                }
            }
            Console.WriteLine(exits + ":");

            if (Player.CurrentLocation.RoomMob != null)
            {
                foreach(Mob mob in Player.CurrentLocation.RoomMob)
                {
                    if(mob.Tracker != 105)
                    {
                        Player.CurrentMob = mob;
                        Console.WriteLine("There is a " + mob.Name + " is in this room.");
                    }
                    else
                    {
                        Player.CurrentMob = mob;
                        Console.WriteLine("The " + mob.Name + " is the boss in this room.");
                    }
                }
            }
        }
    }
}
