﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Item : Object
    {
        //Fields
        private bool _craftable;
        //Default Constructor
        public Item()
        {
            Craftable = true;
        }
        // Custom Constructor
        public Item(string name, string description, int price, int units, bool equip, bool usable, bool craftable)
            : base(name, description, price, units, equip, usable)
        {
            Craftable = craftable;
        }
        // Properties
        public bool Craftable
        {
            get
            {
                return _craftable;
            }
            set
            {
                _craftable = value;
            }
        }
    }
}
