﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class DecisionStructure
    {
       
        // Decides what to do based on userInput in StartMenu
        public static void StartMenuChoice(int choice)
        {
            switch(choice)
            {
                // If user chooses 1, they enter the dungeon
                case 1:
                    EnterDungeon();
                    break;
                // If user chooses 2, display info menu
                case 2:
                    InfoMenu();
                    break;
                // If user chooses 3, exit
                case 3:
                    Console.WriteLine("Goodbye!");
                    break;
            }
        }
        // Display enter dungeon menu
        public static void EnterDungeon()
        {
   
            // Array for mobs
            List<Mob> mobs = new List<Mob>() { new Mob("Wolf", 20, 0, 2, 100),
                                               new Mob("Goblin", 25, 2, 6, 101),
                                               new Mob("Goblin Mage", 30, 3, 8, 102),
                                               new Mob("Hobogoblin", 20, 1, 7, 103),
                                               new Mob("Goblin Commander", 125, 20, 20, 104),
                                               new Mob("Goblin King",250, 50, 35, 105)};
            
            Console.WriteLine("Welcome to Jupiter");
            Console.WriteLine("-------------------------");

            Player myPlayer = new Player();
            myPlayer = BuildPlayer.BuildAPlayer(myPlayer);
            Console.WriteLine(StandardMessages.ShowPlayer(myPlayer));

            bool exit = false;

            CurrentLocation.ShowCurrentLocation();

            while(true)
            { 

                string input = Console.ReadLine();
                if(string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Enter again");
                }
                if (input == "exit")
                {
                    Console.WriteLine("Goodbye");
                    exit = true;
                }
                else 
                {
                    Console.WriteLine("Not valid input!");
                }
                TypeCommand(input, myPlayer);
                Console.ReadLine();
            }
        }
        private static void TypeCommand(string input, Player myPlayer)
        {
            Prompt.PromptCommand(input, myPlayer);
            Console.WriteLine("");
        }
        // Display Info Menu
        public static void InfoMenu()
        {
            bool exit = false;
            do
            {
                Console.WriteLine(StandardMessages.InfoMenu());
                switch (Console.ReadLine())
                {
                    case "1":
                        ArrayHolder.ClassArray();
                        Console.ReadLine();
                        break;
                    case "2":
                        ArrayHolder.RoomArray();
                        Console.ReadLine();
                        break;
                    case "3":
                        ArrayHolder.PotionArray();
                        Console.ReadLine();
                        break;
                    case "4":
                        ArrayHolder.TreasureArray();
                        Console.ReadLine();
                        break;
                    case "5":
                        ArrayHolder.ItemDescriptionArray();
                        Console.ReadLine();
                        break;
                    case "6":
                        ArrayHolder.WeaponArray();
                        Console.ReadLine();
                        break;
                    case "7":
                        ArrayHolder.AbilityArray();
                        Console.ReadLine();
                        break;
                    case "8":
                        ArrayHolder.MobArray();
                        Console.ReadLine();
                        break;
                    case "9":
                        ArrayHolder.StatArray();
                        Console.ReadLine();
                        break;
                    case "10":
                        Console.WriteLine("Goodbye!");
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid input! Choose again..");
                        break;
                }
            } while (exit == false);
        }
        // Sean Created method to check if user inputs a valid option
        public static int MenuChoiceValidation(int choice, int max)
        {
            // Check to see if user inputs an int and that int is between the lowest (always 1) and highest number for choices
            while (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > max)
            {
                // Inform user that input is invalid
                Console.WriteLine(StandardMessages.InputError());
            }
            // Return user input
            return choice;
        }

    }
}
