﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Treasure : Object
    {
        // Fields
        private bool _rare;
        private bool _legendary;
        // Default Constructor
        public Treasure()
        {
            Rare = true;
            Legendary = true;
        }
        // Custom Constructor
        public Treasure(string name, string description, int price, int units, bool equip,
            bool usable, bool rare, bool legend)
            : base(name, description, price, units, equip, usable)
        {
            Rare = rare;
            Legendary = legend;
        }
        // Properties
        public bool Rare
        {
            get
            {
                return _rare;
            }
            set
            {
                _rare = value;
            }
        }
        public bool Legendary
        {
            get
            {
                return _legendary;
            }
            set
            {
                _legendary = value;
            }
        }
    }
}
