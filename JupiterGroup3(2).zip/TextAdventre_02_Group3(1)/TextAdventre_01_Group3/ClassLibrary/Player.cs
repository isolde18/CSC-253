﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Player : Character
    {
        //Fields
        private string _password;
        private string _class;
        private string _race;
        private int _mana;
        private int _dexterity;
        private int _vitality;
        private int _wisdom;
        private int _damage;
        public static Room _currentLocation;
        public static Mob _currentMob;
        public static Player player;
        
        // Default Constructor
        public Player()
        {
            Class = "No Class";
            Race = "No Race";
            Damage = 0;
            Mana = 0;
            Dexterity = 0;
            Vitality = 0;
            Wisdom = 0;
        }
        // Custom Constructor
        public Player(string name, int health, int armorpts, string playerClass, string race, int mana, int dexterity,
                      int vitality, int wisdom, int damage) : base(name, health, armorpts)
        {
            Class = playerClass;
            Race = race;
            Mana = mana;
            Damage = damage;
            Dexterity = dexterity;
            Vitality = vitality;
            Wisdom = wisdom;
            CurrentLocation = Tracker.rooms[0];
        }
        // Properties
        public string Class
        {
            get
            {
                return _class;
            }
            set
            {
                _class = value;
            }
        }
        public string Race
        {
            get
            {
                return _race;
            }
            set
            {
                _race = value;
            }
        }
        public int Mana
        {
            get
            {
                return _mana;
            }
            set
            {
                _mana = value;
            }
        }
        public int Dexterity
        {
            get
            {
                return _dexterity;
            }
            set
            {
                _mana = value;
            }
        }
        public int Vitality
        {
            get
            {
                return _vitality;
            }
            set
            {
                _vitality = value;
            }
        }
        public int Wisdom
        {
            get
            {
                return _wisdom;
            }
            set
            {
                _wisdom = value;
            }
        }
        public int Damage
        {
            get
            {
                return _damage;
            }
            set
            {
                _damage = value;
            }
        }
        public static Room CurrentLocation { get { return _currentLocation; } set { _currentLocation = value; } }
        public string Password { get { return _password; } set { _password = value; } }
        public static Mob CurrentMob { get { return _currentMob; } set { _currentMob = value; } }
    }
}
