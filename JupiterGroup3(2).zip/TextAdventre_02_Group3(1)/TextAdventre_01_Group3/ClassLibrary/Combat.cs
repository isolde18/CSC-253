﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Combat
    {
        public static Mob BuildMobCombat()
        {
            Mob myMob = new Mob();
            myMob.Armor = 10;
            myMob.AttackDamage = 20;
            myMob.Health = 150;
            return myMob;
        }
        public static Player BuildPlayerCombat(int health)
        {
            Player myPlayer = new Player();
            myPlayer.Damage = 25;
            myPlayer.Armor = 10;
            myPlayer.Health = health;

            return myPlayer;
        }
        public static int DealPlayerDamage(Player myCharacter, Mob myMob)
        {
            int playerDamageDealt = myCharacter.Damage - myMob.Armor;
            return playerDamageDealt;
        }
        public static int DealMobDamage(Player myCharacter, Mob myMob)
        {
            int mobDamageDealt = myMob.AttackDamage - myCharacter.Armor;
            return mobDamageDealt;
        }
        public static int PlayerHP(Player myCharacter, int damage)
        {
            int playerHP = myCharacter.Health - damage;
            return playerHP;
        }
        public static int MobHP(Mob myMob, int damage)
        {
            int mobHP = myMob.Health - damage;
            return mobHP;
        }
        public static void ToAttack(ref List<Mob> mobs, Player myPlayer)
        {

            Console.WriteLine(StandardMessages.CombatDealt(Combat.DealPlayerDamage(Combat.BuildPlayerCombat(myPlayer.Health), Combat.BuildMobCombat()),
            Combat.DealMobDamage(Combat.BuildPlayerCombat(myPlayer.Health), Combat.BuildMobCombat()), Combat.PlayerHP(Combat.BuildPlayerCombat(myPlayer.Health),
            Combat.DealMobDamage(Combat.BuildPlayerCombat(myPlayer.Health), Combat.BuildMobCombat())), Combat.MobHP(Combat.BuildMobCombat(),
            Combat.DealPlayerDamage(Combat.BuildPlayerCombat(myPlayer.Health), Combat.BuildMobCombat()))));

        }
    }
}
