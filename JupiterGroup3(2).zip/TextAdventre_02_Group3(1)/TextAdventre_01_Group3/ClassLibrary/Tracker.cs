﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public static class Tracker
    {
        public static List<Room> rooms = new List<Room>() {new Room("Dungeon Entrance", "The start area of the dugeon of Jupiter", 1, 2, -1, -1, -1),
                               new Room("Wolf Den", "A place where the wolves group and is dangerous to be in.", 2,-1,3,1,-1),
                               new Room("Eerie Room", "A spooky room *gasp* could be a ghost in here.", 3, 4,-1,-1,2),
                               new Room("Treasure Room", "This room contains a mob and it will choose at random." +
                             " and will spawn a treasure if you defeat it", 4, 5,-1,3,-1),
                               new Room("Cave Room", "A very dark and gleemy room that is very closed in hard to be in.",
                             5, -1,-1,4,6),
                               new Room("Ancient Room", "A room that is covered in thousands of artifacts and treasures.",
                              6, -1,5,-1,7),
                               new Room("Hologram Room", "A very confusing that projects these objects that move with you.",
                              7, -1,6,8,-1),
                               new Room("Maze Room", "This room is a test to move around tp figure out your escape.",
                              8, 7,-1,-1,9),
                               new Room("Secret Room", "This room is really just a secret its random with something in it.",
                              9, -1,8,10,-1),
                               new Room("Boss Room", "This room is the end of the dungeon and this spawns the Goblin King",
                             10, 9,-1,-1,-1)};
        public static Room RoomByTracker(int tracker)
        {
            return rooms.SingleOrDefault(x => x.Tracker == tracker);
        }
    }
}
